import Vue from 'vue'

var bus = new Vue();

export default bus;